<?php 
// Código usado apenas para confirmar a conexão nos processos de teste.
require_once "conexao.php";

echo "Conexao funcionando";
?>


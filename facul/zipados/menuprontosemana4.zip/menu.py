"""
Nome: Arthur Andrade De Marco  
Curso: Análise e Desenvolvimento de Sistema  
Descrição: Aqui segue a primeira atividade somativa da semana 4 da matéria de Raciocínio Computacional. 

"""
# Lista para a verificação do alunos
estudantes = []

# Bibliotecas e função para poder limpar a tela no código.
import os, sys, re 

def limpar_tela():
    if sys.platform == "win32": 
        os.system("cls")
    else:
        os.system("clear")

# Início do progama, apresentando o menu principal e as opções pedidas.

while True:
    limpar_tela()
    print("---- MENU PRINCIPAL ----")
    print("(1) Gerenciar Estudantes ")
    print("(2) Gerenciar Professores ")
    print("(3) Gerenciar Disciplinas ")
    print("(4) Gerenciar Turmas ")
    print("(5) Gerenciar Matriculas ")
    print("(9) Sair")
    
    opcao = str(input("Digite o valor respectivo a funcao de sua preferencia: "))

# Gerenciamento dos Estudantes
    
    if opcao == "1":
        while True:
            limpar_tela()
            print("***** [ALUNOS] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_aluno = str(input("Digite o valor respectivo a funcao de sua preferencia: "))

# Opcão de inclusão de nomes na lista
        
            if opcao_aluno == "1":
               while True:
                    nome_aluno = input("Informe o nome do aluno: ").strip()
        
                # Verifica se o nome contém apenas letras e espaços
                    if re.match(r"^[A-Za-zÀ-ÿ\s]+$", nome_aluno):  
                        estudantes.append(nome_aluno)
                        input("\nAluno cadastrado com sucesso!"
                              "\nPressione ENTER para continuar..."
                              )
                        break
                    else:
                        print("Erro: O nome não pode conter números ou caracteres especiais. Tente novamente.")


# Opcão de listagem de estudandes

            elif opcao_aluno == "2":
                if not estudantes:
                    print("Não há estudantes cadastrados.")
                else:
                    print("Lista de estudantes:")
                for nome_aluno in estudantes:
                    print("-", nome_aluno)
                input("\nPressione ENTER para continuar...")
            
# Resto das opções (EM DESENVOLVIMENTO) como solicitado

            elif opcao_aluno == "3":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_aluno == "4":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_aluno == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

# Outras opções do menu com saída de (EM DESENVOLVIMENTO) como pedido
    elif opcao == "2":
        print("EM DESENVOLVIMENTO")
        input("\nPressione ENTER para continuar...")

    elif opcao == "3":
        print("Em desenvolvimento")
        input("\nPressione ENTER para continuar...")

    elif opcao == "4":
        print("Em desenvolvimento")
        input("\nPressione ENTER para continuar...")

    elif opcao == "5":
        print("Em desenvolvimento")
        input("\nPressione ENTER para continuar...")

    elif opcao == "9":
        print("Saindo...")
        break
    else:
        print("Opção inválida!")
        input("\nPressione ENTER para continuar...")
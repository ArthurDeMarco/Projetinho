
import os, sys

def limpar_tela():
    if sys.platform == "win32": 
        os.system("cls")
    else:
        os.system("clear")

while True:
    limpar_tela()
    print("---- MENU PRINCIPAL ----")
    print("(1) Gerenciar Estudantes ")
    print("(2) Gerenciar Professores ")
    print("(3) Gerenciar Disciplinas ")
    print("(4) Gerenciar Turmas ")
    print("(5) Gerenciar Matriculas ")
    print("(9) Sair")
    
    opcao = str(input("Digite o valor respectivo a funcao de sua preferencia: "))
    
    if opcao == "1":
        while True:
            limpar_tela()
            print("***** [ALUNOS] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_aluno = str(input("Digite o valor respectivo a funcao de sua preferencia: "))
        
            if opcao_aluno == "1":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_aluno == "2":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_aluno == "3":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_aluno == "4":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_aluno == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

    elif opcao == "2":
        while True:
            limpar_tela()
            print("***** [PROFESSORES] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_professores = str(input("Digite o valor respectivo a funcao de sua preferencia: "))
        
            if opcao_professores == "1":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_professores == "2":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_professores == "3":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_professores == "4":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_professores == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

    elif opcao == "3":
        while True:
            limpar_tela()
            print("***** [ALUNOS] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_disciplina = str(input("Digite o valor respectivo a funcao de sua preferencia: "))
        
            if opcao_disciplina == "1":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_disciplina == "2":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_disciplina == "3":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_disciplina == "4":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_disciplina == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

    elif opcao == "4":
        while True:
            limpar_tela()
            print("***** [ALUNOS] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_turmas = str(input("Digite o valor respectivo a funcao de sua preferencia: "))
        
            if opcao_turmas == "1":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_turmas == "2":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_turmas == "3":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_turmas == "4":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_turmas == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

    elif opcao == "5":
        while True:
            limpar_tela()
            print("***** [ALUNOS] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_matriculas = str(input("Digite o valor respectivo a funcao de sua preferencia: "))
        
            if opcao_matriculas == "1":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_matriculas == "2":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_matriculas == "3":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")

            elif opcao_matriculas == "4":
                print("Em desenvolvimento")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_matriculas == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

    elif opcao == "9":
        print("Saindo...")
        break
    else:
        print("Opção inválida!")
        input("\nPressione ENTER para continuar...")

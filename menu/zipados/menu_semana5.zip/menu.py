"""
Nome: Arthur Andrade De Marco  
Curso: Análise e Desenvolvimento de Sistema  
Descrição: Aqui segue a primeira atividade somativa da semana 4 da matéria de Raciocínio Computacional. 

"""
# Lista para a verificação do alunos
estudantes = {}

# Bibliotecas e função para poder limpar a tela no código.
import os, sys, re 

def limpar_tela():
    if sys.platform == "win32": 
        os.system("cls")
    else:
        os.system("clear")

# Início do progama, apresentando o menu principal e as opções pedidas.

while True:
    limpar_tela()
    print("---- MENU PRINCIPAL ----")
    print("(1) Gerenciar Estudantes ")
    print("(2) Gerenciar Professores ")
    print("(3) Gerenciar Disciplinas ")
    print("(4) Gerenciar Turmas ")
    print("(5) Gerenciar Matriculas ")
    print("(9) Sair")
    
    opcao = str(input("Digite o valor respectivo a funcao de sua preferencia: "))

# Gerenciamento dos Estudantes
    
    if opcao == "1":
        while True:
            limpar_tela()
            print("***** [ALUNOS] MENU DE OPERACOES *****")
            print("(1) Incluir. ")
            print("(2) Listar. ")
            print("(3) Atualizar. ")
            print("(4) Excluir. ")
            print("(5) Voltar ao menu principal. ")

            opcao_aluno = str(input("Digite o valor respectivo a funcao de sua preferencia: "))

# Opcão de inclusão de nomes na lista
        
            if opcao_aluno == "1":
               while True:
                    limpar_tela()
                    nome_aluno = str(input("Informe o nome do aluno: "))
                    cpf_aluno = str(input("Informe o CPF do aluno: ")).strip()
                    codigo_aluno = int(input("Informe o codigo do estudante: "))      
                    
                # Verifica se o nome contém apenas letras e espaços
                
                    if re.match(r"^[A-Za-zÀ-ÿ\s]+$",nome_aluno):
                        estudantes[codigo_aluno] = {
                            "cpf_aluno": cpf_aluno,
                            "nome_aluno": nome_aluno
                        }
                        input("\nAluno cadastrado com sucesso!"
                              "\nPressione ENTER para continuar..."
                              )
                        if input("\nDeseja adicionar outro nome? (s/n): ").strip().lower() == "n":                          
                            break
                    else:
                        print("Erro: O nome não pode conter números ou caracteres especiais. Tente novamente.")


# Opcão de listagem de estudandes

            elif opcao_aluno == "2":
                if not estudantes:
                    print("Não há estudantes cadastrados.")
                else:
                    print("Lista de estudantes:")
                for codigo_aluno in estudantes:
                    dados = estudantes[codigo_aluno]
                    print(f" Código - {codigo_aluno:<10} | Nome - {dados['nome_aluno']:<20} | CPF - {dados['cpf_aluno']:<14}")   
                input("\nPressione ENTER para continuar...")
            
# Funcao de atualizar

            elif opcao_aluno == "3":
                
                cod = input("Informe o código do aluno que deseja atualizar: ").strip()

                if cod.isdigit():
                    cod = int(cod)
                    if cod in estudantes:
                        novo_nome = input("Informe o novo nome do aluno: ").strip()
                        novo_codigo = input("Informe o novo código do aluno: ").strip()
                        novo_cpf = input("Informe o novo CPF do aluno: ").strip()

                        if not novo_codigo.isdigit():
                            print("Código inválido. Deve ser numérico.")
                        elif not re.match(r"^[A-Za-zÀ-ÿ\s]+$", novo_nome):
                            print("Nome inválido. Use apenas letras e espaços.")
                        else:
                            novo_codigo = int(novo_codigo)

                            # Se o código foi alterado, cria novo e remove o antigo
                            if novo_codigo != cod:
                                estudantes[novo_codigo] = estudantes.pop(cod)
                                cod = novo_codigo  # Atualiza referência pro novo código

                            # Atualiza nome e CPF
                            estudantes[cod]["nome_aluno"] = novo_nome
                            estudantes[cod]["cpf_aluno"] = novo_cpf

                            print("Dados atualizados com sucesso!")
                    else:
                        print("Código de aluno não encontrado.")
                else:
                    print("Código inválido. Deve ser um número.")

                input("\nPressione ENTER para continuar...")

# Funcao de excluir um aluno

            elif opcao_aluno == "4":
                cod = input("Informe o código do aluno: ").strip()

                if cod.isdigit():  # Verifica se é número
                    cod = int(cod)  # Converte para inteiro
                    if cod in estudantes:
                        estudantes.pop(cod)
                        print("Aluno excluído com sucesso.")
                    else:
                         print("O código informado não está cadastrado.")
                else:
                    print("Código inválido. Deve ser um número.")
                input("\nPressione ENTER para continuar...")
        
            elif opcao_aluno == "5":
                print("Saindo...")
                break
            else:
                print("Opção inválida!")
                input("\nPressione ENTER para continuar...")

# Outras opções do menu com saída de (EM DESENVOLVIMENTO) como pedido
    elif opcao == "2":
        print("EM DESENVOLVIMENTO")
        input("\nPressione ENTER para continuar...")

    elif opcao == "3":
        print("Em desenvolvimento")
        input("\nPressione ENTER para continuar...")

    elif opcao == "4":
        print("Em desenvolvimento")
        input("\nPressione ENTER para continuar...")

    elif opcao == "5":
        print("Em desenvolvimento")
        input("\nPressione ENTER para continuar...")

    elif opcao == "9":
        print("Saindo...")
        break
    else:
        print("Opção inválida!")
        input("\nPressione ENTER para continuar...")